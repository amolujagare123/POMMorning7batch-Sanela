package regression;

public class ForgotPassordtest {
}
