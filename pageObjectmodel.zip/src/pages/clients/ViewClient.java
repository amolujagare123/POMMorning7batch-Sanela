package pages.clients;

public class ViewClient {
}
