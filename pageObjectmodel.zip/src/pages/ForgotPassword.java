package pages;

public class ForgotPassword {
}
